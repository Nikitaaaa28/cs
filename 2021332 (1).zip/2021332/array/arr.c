#include<stdio.h>
#include<stdlib.h>
int main()
{
    int m,n,k,f=0;
    int i=0,j=0;
    printf("Input number of rows:\n ");
    scanf("%d",&m);
    printf("\nInput number of columns: \n");
    scanf("%d",&n);
   int **mat = (int **)malloc(m*sizeof(int *));//rows
    for(i=0;i<m;i++)
    {
        mat[i] = (int *)malloc(n*sizeof(int));//columns
    }
     printf("Input element to search : ");
    scanf("%d",&k);
    printf(" \nelements :\n ");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }
   
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            if(mat[i][j] == k)
            {
                printf("Element found at %d row and %d column.\n",i+1,j+1);
                f= 1;
                break;
            }
        }
    }
    if(f == 0)
        printf("\n not found\n");
    return 0;
}