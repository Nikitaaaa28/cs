#include<stdio.h>
#include<stdlib.h>
int main()
{
    int **matrix,m,n;
    int i=0,j=0;
    printf("Input number of rows:\n ");
    scanf("%d",&m);
    printf("\nInput number of columns: \n");
    scanf("%d",&n);
    matrix = (int **)malloc(m*sizeof(int *));//rows
    for(i=0;i<m;i++)//columns
    {
        matrix[i] = (int *)malloc(n * sizeof(int));
    }
    printf("\nEnter elements : \n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&matrix[i][j]);
        }
    }
    printf("\nMatrix : \n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
    return 0;
}