//doubly linked list code with tail
#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next, *prev;
};
//getting values
struct node* accept(int n,struct node **head,struct node**tail,struct node **temp){
	*head= (struct node *)malloc(sizeof(struct node));
    *tail= (struct node *)malloc(sizeof(struct node));

	if(*head==NULL){
		printf("memory allocation failed");
		exit(0);
	}
	int val,i=1;
	printf("\nEnter the data: ");
	scanf("%d", &val);
	(*head)->data=val;
	(*head)->next= NULL;
    (*head)->prev= NULL;
	*temp= *head;
	for( i=2;i<n;i++){
		struct node *p= (struct node *)malloc(sizeof(struct node));
		if(p == NULL){
			printf("memory allocation failed");
			break;
		}
		int k;
		printf("\nEnter the data: ");
		scanf("%d", &k);
		p->data= k;
		p->next= NULL;
		(*temp)->next= p;
        p->prev=(*temp);
		*temp= (*temp)->next;
	}
    printf("\nEnter the data: ");
    scanf("%d",&val);
    (*tail)->data=val;
    (*temp)->next=*tail;
    (*tail)->next=NULL;
    (*tail)->prev=*temp;
    
    return *head;
}
//INSERT AT BEGINNING
void addToBegin(struct node**head,struct node**tail,int data)
{
  struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
temp->prev=NULL;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
temp->next=*head;
(*head)->prev=temp;
*head=temp;
}
//INSERT AT END
void addToEnd(struct node**head,struct node**tail,int data)
{
struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
temp->prev=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head) && !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
    (*tail)->next=temp;
    temp->prev=*tail;
   *tail=temp;

}
//insert after a given value if not then at the end
void addAfter(struct node**head,struct node**tail,int data,int k)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
temp->prev=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
    while((itr!=NULL)&& (itr->data!=k))
        itr=itr->next;
        if(itr->data)
        {
          temp->next=itr->next;
          itr->next=temp;
          temp->prev=itr;
          temp->next->prev=temp;
        }
        else{
             (*tail)->next=temp;
              temp->prev=*tail;
              *tail=temp;
        }
}
//insert before a given value if not then at the start
void beforeAfter(struct node**head,struct node**tail,int data,int k)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
temp->prev=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
    while((itr->next->next!=NULL)&& (itr->next->data!=k))
        itr=itr->next;
        if(itr->next->data)
        {
          temp->next=itr->next;
          itr->next=temp;
          temp->next->prev=temp->prev;
          temp->next->prev=temp;
        }
        else{
            temp->next=*head;
            (*head)->prev=temp;
            *head=temp;
        }
}
//delete at start
void DeleteAtStart(struct node **head,struct node **tail)
{
    struct node *temp=*head;
    if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
    else if((*head)->next==NULL)
    {
        *head=*tail=NULL;
        free(temp);
        return;
    }
    else
    {
    *head=(*head)->next;
    (*head)->prev=NULL;
    free(temp);
    }
}
//DELETE AT TAIL
void DeleteAtEnd(struct node **head,struct node**tail)
{
    struct node *temp=*tail;
    if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
    else if((*head)==(*tail))
    {
        *tail=NULL;
        *head=NULL;
        free(temp);
        return;
    }
    *tail=(*tail)->prev;
    (*tail)->next=NULL;
    free(temp);
}
//DELETE FROM VALUE K
void DeleteAtk(struct node **head,int k,struct node **tail)
{
struct node *itr=*head,*temp=NULL;
 if(!(*head)&& !(*tail))//no node
{
    *head=*tail=temp;
    return;
}
if((itr->data==k)|| ((*head)->next==NULL))
{
    *head=(*head)->next;
    *head=NULL;
    free(itr);
    return;
}
while(itr->next->next!=NULL && itr->next->data!=k)
itr=itr->next;
if(itr)
{
    if(itr->next)
    itr->next->prev=itr->prev;
    else
    {
        *tail=(*tail)->prev;
        (*tail)->next=NULL;
    }
    if(itr->prev)
        itr->prev->next=itr->next;
    else
    *head=(*head)->next;
}
free(itr);
}
void display(struct node **p){
	int i=1;
	while(*p!=NULL)
    {
		printf("\nData for the node %d is: %d", i, (*p)->data);
		*p= (*p)->next;
		i++;
	}
}
int main()
{
    int n,ch,k;
    int data;
    struct node*head;
    struct node*temp;
    struct node*tail;
	printf("Enter the number of nodes:\n ");
	scanf("%d",&n);
    do
    {
         
     printf("\nmenu driven...\n");
     printf("1.Insert at begin\n 2.Insert at end\n 3.Insert after node\n 4.Insert before node\n 5.Delete from start\n 6.Delete from end\n 7.Delete a value k\n 8.exit\n");
     printf("Enter your choice\n");
     scanf("%d",&ch);
     switch(ch)
     {
        case 1:
       // int data;
        head=accept(n,&head,&tail,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
        addToBegin(&head,&tail,data);
        display(&head);
        break;
        case 2:
       // int data;
        head=accept(n,&head,&tail,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
        addToEnd(&head,&tail,data);
        display(&head);
        break;
         case 3:
     //   int data,k;
        head=accept(n,&head,&tail,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
         printf("\nenter the value after which to insert :\n");
        scanf("%d",&k);
        addAfter(&head,&tail,data,k);
        display(&head);
        break;
         case 4:
    //    int data,k;
        head=accept(n,&head,&tail,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
         printf("\nenter the value before which to insert :\n");
        scanf("%d",&k);
       beforeAfter(&head,&tail,data,k);
        display(&head);
        break;
        case 5:
        head=accept(n,&head,&tail,&temp);
        DeleteAtStart(&head,&tail);
        display(&head);
        break;
         case 6:
        head=accept(n,&head,&tail,&temp);
        DeleteAtEnd(&head,&tail);
        display(&head);
        break;
         case 7:
       //  int k;
        printf("\n enter value to be deleted\n");
        scanf("%d",&k);
        head=accept(n,&head,&tail,&temp);
        DeleteAtk(&head,k,&tail);
        display(&head);
        break;
        case 8:
        exit(0);
        default:
        printf("\n wrong choice");
     }
    }
    while(1);
    return 0;
}