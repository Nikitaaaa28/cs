//singly linked list code
#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
//getting values
struct node* accept(int n,struct node **head,struct node **temp){
	*head= (struct node *)malloc(sizeof(struct node));
	if(*head==NULL){
		printf("memory allocation failed");
		exit(0);
	}
	int val,i=1;
	printf("\nEnter the data: ");
	scanf("%d", &val);
	(*head)->data=val;
	(*head)->next= NULL;
	*temp= *head;
	for( i=2;i<=n;i++){
		struct node *p= (struct node *)malloc(sizeof(struct node));
		if(p == NULL){
			printf("memory allocation failed");
			break;
		}
		int k;
		printf("\nEnter the data: ");
		scanf("%d", &k);
		p->data= k;
		p->next= NULL;
		(*temp)->next= p;
		*temp= (*temp)->next;
	}
    return *head;
}
//INSERT AT BEGINNING
void addToBegin(struct node**head,int data)
{
  struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head))//no node
{
    *head=temp;
    return;
}
temp->next=*head;
*head=temp;
}
//INSERT AT END
void addToEnd(struct node**head,int data)
{
struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head))//no node
{
    *head=temp;
    return;
}
while(itr->next!=NULL)
{
    itr=itr->next;
}
    itr->next=temp;
}
//insert after a given value if not then at the end
void addAfter(struct node**head,int data,int k)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head))//no node
{
    *head=temp;
    return;
}
    while((itr->next!=NULL)&& (itr->data!=k))
        itr=itr->next;
        if(itr->data)
        {
          temp->next=itr->next;
          itr->next=temp;
        }
        else{
            itr->next=temp;
            temp->next=NULL;
        }
}
//insert before a given value if not then at the start
void beforeAfter(struct node**head,int data,int k)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
temp->data=data;
temp->next=NULL;
struct node *itr=*head;
if(temp==NULL)
{
    printf("FAILURE IN MEMORY ALLOCATION" );
    return;
}  
if(!(*head))//no node
{
    *head=temp;
    return;
}
    while((itr->next->next!=NULL)&& (itr->next->data!=k))
        itr=itr->next;
        if(itr->next->data)
        {
          temp->next=itr->next;
          itr->next=temp;
        }
        else{
            temp->next=*head;
            *head=temp;
        }
}
//delete at start
void DeleteAtStart(struct node **head)
{
    struct node *temp=*head;
    if(!(*head))
    return;
    *head=(*head)->next;
    free(temp);
}
//DELETE AT TAIL
void DeleteAtEnd(struct node **head)
{
    struct node *itr=*head;
    struct node *temp=NULL;
    if(!(*head))
    return;
    if((*head)->next==NULL)
    {
        temp=*head;
        *head=NULL;
        free(temp);
        return;
    }
    while(itr->next->next!=NULL)
    itr=itr->next;
    temp=itr->next;
    itr->next=NULL;
    free(temp);
}
//DELETE FROM VALUE K
void DeleteAtk(struct node **head,int k)
{
struct node *itr=*head,*temp=NULL;
if(!(*head))
return;
if(itr->data==k)
{
    *head=(*head)->next;
    free(itr);
    return;
}
while(itr->next!=NULL && itr->next->data!=k)
itr=itr->next;
if(itr->next)
{
    temp=itr->next;
    itr->next=temp->next;
    free(temp);
}
}
void display(struct node **p){
	int i=1;
	while(*p!=NULL)
    {
		printf("\nData for the node %d is: %d", i, (*p)->data);
		*p= (*p)->next;
		i++;
	}
}
int main()
{
    int n,ch,k;
    int data;
    struct node*head;
    struct node*temp;
	printf("Enter the number of nodes:\n ");
	scanf("%d",&n);
    do
    {
         
     printf("\nmenu driven...\n");
     printf("1.Insert at begin\n 2.Insert at end\n 3.Insert after node\n 4.Insert before node\n 5.Delete from start\n 6.Delete from end\n 7.Delete a value k\n 8.exit\n");
     printf("Enter your choice\n");
     scanf("%d",&ch);
     switch(ch)
     {
        case 1:
       // int data;
        head=accept(n,&head,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
        addToBegin(&head,data);
        display(&head);
        break;
        case 2:
       // int data;
        head=accept(n,&head,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
        addToEnd(&head,data);
        display(&head);
        break;
         case 3:
     //   int data,k;
        head=accept(n,&head,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
         printf("\nenter the value after which to insert :\n");
        scanf("%d",&k);
        addAfter(&head,data,k);
        display(&head);
        break;
         case 4:
    //    int data,k;
        head=accept(n,&head,&temp);
        printf("\nenter the value to insert:\n");
        scanf("%d",&data);
         printf("\nenter the value before which to insert :\n");
        scanf("%d",&k);
       beforeAfter(&head,data,k);
        display(&head);
        break;
        case 5:
        head=accept(n,&head,&temp);
        DeleteAtStart(&head);
        display(&head);
        break;
         case 6:
        head=accept(n,&head,&temp);
        DeleteAtEnd(&head);
        display(&head);
        break;
         case 7:
       //  int k;
        printf("\n enter value to be deleted\n");
        scanf("%d",&k);
        head=accept(n,&head,&temp);
        DeleteAtk(&head,k);
        display(&head);
        break;
        case 8:
        exit(0);
        default:
        printf("\n wrong choice");
     }
    }
    while(1);
    return 0;
}